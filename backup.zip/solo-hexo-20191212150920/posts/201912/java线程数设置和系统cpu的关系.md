title: java线程数设置和系统cpu的关系
date: '2019-12-05 11:30:12'
updated: '2019-12-05 11:30:12'
tags: [待分类]
permalink: /articles/2019/12/05/1575516612700.html
---
这里的cpu个数不是指系统的cpu总个数，也不是指cpu总核心数，而是指cpu的总逻辑处理单元即超线程的个数。

**IO密集型程序（如数据库数据交互、文件上传下载、网络数据传输等等）设置线程数为2倍的总逻辑处理单元个数。**

**计算密集型程序（如数据转换，递归，复杂算法，加解密程序）设置线程数为总逻辑处理单元个数+1**。

**java中总逻辑处理单元个数获取方法：`Runtime.getRuntime().availableProcessors()`**

 

一般我们说一台电脑有多少个物理cpu，共多少核，共多少线程。

 

CPU总核数 = 物理CPU个数 * 每颗物理CPU的核数；  
总逻辑CPU数 = 物理CPU个数 * 每颗物理CPU的核数 * 超线程数；

 

windows查看总逻辑cpu数方法：

![](https://img2018.cnblogs.com/blog/1582259/201907/1582259-20190723212234315-1086980329.png)

1、设备管理器->处理器

如图共4个逻辑CPU数/逻辑处理单元/线程

2、任务管理器->性能

如图4个槽就代表4个逻辑CPU数/逻辑处理单元/线程

**一般，总核心数=总逻辑CPU数/2**

 

linux查看总逻辑cpu数方法：

查看CPU信息（型号）
[root@AAA ~]# cat /proc/cpuinfo | grep name | cut -f2 -d: | uniq -c
     24         Intel(R) Xeon(R) CPU E5-2630 0 @ 2.30GHz

# 查看物理CPU个数
[root@AAA ~]# cat /proc/cpuinfo| grep "physical id"| sort| uniq| wc -l
2

# 查看每个物理CPU中core的个数(即核数)
[root@AAA ~]# cat /proc/cpuinfo| grep "cpu cores"| uniq
cpu cores    : 6

# 查看逻辑CPU的个数
[root@AAA ~]# cat /proc/cpuinfo| grep "processor"| wc -l
24

[https://www.cnblogs.com/bugutian/p/6138880.html](https://www.cnblogs.com/bugutian/p/6138880.html)
