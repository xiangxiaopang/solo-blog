title: Arrays.AsLIst  add remove异常v
date: '2019-11-29 15:08:53'
updated: '2019-11-29 15:08:53'
tags: [待分类]
permalink: /articles/2019/11/29/1575011333849.html
---
案例是这样的  map<String, List<对象>>
当map put 

 map.put ("1", Ayyays.asLIst(item));

 当id 一样 在次put的时候  就是map.get("1").add(item)

 这个时候会报异常  异常原因
    调用Arrays.asList()生产的List的add、remove方法时报异常，这是由Arrays.asList() 返回的是Arrays的内部类ArrayList， 而不是java.util.ArrayList。Arrays的内部类ArrayList和java.util.ArrayList都是继承AbstractList，remove、add等方法AbstractList中是默认throw UnsupportedOperationException而且不作任何操作。java.util.ArrayList重新了这些方法而Arrays的内部类ArrayList没有重新，所以会抛出异常。


 解决方法  在转一下ArrayList  或者在put的时候    map.put (id, Lists.newArrayList(item));
