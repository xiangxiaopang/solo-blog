title: JAVA导入Excel 报错 java.io.IOException- Zip bomb detected!
date: '2019-11-29 15:09:27'
updated: '2019-11-29 15:09:27'
tags: [待分类]
permalink: /articles/2019/11/29/1575011367652.html
---
 加入一行代码

 ZipSecureFile.setMinInflateRatio(-1.0d);
